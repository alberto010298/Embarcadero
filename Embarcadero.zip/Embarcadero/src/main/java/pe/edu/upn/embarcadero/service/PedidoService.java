package pe.edu.upn.embarcadero.service;

import pe.edu.upn.embarcadero.model.entity.Pedido;

public interface PedidoService extends CrudService<Pedido, Integer>{

}
