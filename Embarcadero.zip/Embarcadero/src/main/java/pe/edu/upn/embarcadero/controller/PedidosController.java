package pe.edu.upn.embarcadero.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import pe.edu.upn.embarcadero.model.entity.Pedido;
import pe.edu.upn.embarcadero.model.entity.Usuario;
import pe.edu.upn.embarcadero.service.PedidoService;
import pe.edu.upn.embarcadero.service.UsuarioService;

@Controller
@RequestMapping("/pedido")
@SessionAttributes({"pedido"})
public class PedidosController {

	@Autowired
	PedidoService pedidoService;
	
	@Autowired
	UsuarioService usuarioService;
	
	@GetMapping
	public String inicio(Model model){
		try {
			List<Pedido> pedido=pedidoService.findAll();
			model.addAttribute("pedido",pedido);
		} catch (Exception e) {
		}
		return "pedido/inicio.html";
	}
	
	@GetMapping("/actualizar/{id}")
	public String editar(@PathVariable("id") Integer id,Model model) {
		try {
			Optional<Pedido>optional=pedidoService.findById(id);
			if(optional.isPresent()) {
				model.addAttribute("pedido",optional.get());
			}else {
				return "redirect:/pedido";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "pedido/edit.html";
	}
	
	@GetMapping("/register")
	public String nuevo(Model model) {
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String currentPrincipalName = authentication.getName();
			model.addAttribute("currentPrincipalName", currentPrincipalName);
			}catch (Exception e) {
				
		}
		try {
			Pedido pedido=new Pedido();
			model.addAttribute("pedido",pedido);
		} catch (Exception e) {
		}
		return "pedido/register.html";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute("pedido") Pedido pedido, Model model, SessionStatus status) {
		try {
			
			pedido.setEstadoRegistro("PENDIENTE");
			pedidoService.save(pedido);
			status.setComplete();
			model.addAttribute("success", "Pedido guardado");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/pedido";
	}
	
	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable("id") Integer id, Model model) {
		try {
			Optional<Pedido> pedidoOptional=pedidoService.findById(id);
			if(pedidoOptional.isPresent()) {
				pedidoService.deleteById(id);
			}
		} catch (Exception e) {
			model.addAttribute("danger_del","Error - Violacion contra el principio de integridad referencial");
			try {
				List<Pedido> pedido=pedidoService.findAll();
				model.addAttribute("pedido",pedido);
			} catch (Exception e1) {
			}
			return "/pedido/inicio";
		}
		return "redirect:/pedido";
	}
	
	@GetMapping("/confirmado/{id}")
	public String estadoConfirmado(@PathVariable("id") Integer id,Model model,SessionStatus status) {
		try {
			Optional<Pedido>optional=pedidoService.findById(id);
			if(optional.isPresent()) {
				optional.get().setEstadoRegistro("CONFIRMADO");
				pedidoService.save(optional.get());
				status.setComplete();
			}else {
				return "/pedido/inicio";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/pedido";
	}
	@GetMapping("/servido/{id}")
	public String estadoServido(@PathVariable("id") Integer id,Model model,SessionStatus status) {
		try {
			Optional<Pedido>optional=pedidoService.findById(id);
			if(optional.isPresent()) {
				optional.get().setEstadoRegistro("SERVIDO");
				pedidoService.save(optional.get());
				status.setComplete();
			}else {
				return "/pedido/inicio";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/pedido";
	}
	@GetMapping("/pendiente/{id}")
	public String estadoPendiente(@PathVariable("id") Integer id,Model model,SessionStatus status) {
		try {
			Optional<Pedido>optional=pedidoService.findById(id);
			if(optional.isPresent()) {
				optional.get().setEstadoRegistro("PENDIENTE");
				pedidoService.save(optional.get());
				status.setComplete();
			}else {
				return "/pedido/inicio";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/pedido";
	}
}
