package pe.edu.upn.embarcadero.model.entity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "pedidos")
public class Pedido {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "descripcion", length = 60)
	private String descripcion;
	
	@Column(name = "fec_pedido")
	@DateTimeFormat(pattern="yyyy-MM-dd h:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar fechaPedido;
	
	@Column(name = "estado_registro", length = 60)
	private String estadoRegistro;
	
	@OneToMany(mappedBy = "pedido", fetch = FetchType.LAZY)
	public List<Detalle> detalles;
	
	public Pedido() {
		this.detalles = new ArrayList<>();
	}
	
	public void addDetalle(Detalle detalle) {
		detalle.setPedido(this);
		this.detalles.add(detalle);
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Calendar getFechaPedido() {
		return fechaPedido;
	}
	public void setFechaPedido(Calendar fechaPedido) {
		this.fechaPedido = fechaPedido;
	}
	
	public String getEstadoRegistro() {
		return estadoRegistro;
	}
	public void setEstadoRegistro(String estadoRegistro) {
		this.estadoRegistro = estadoRegistro;
	}
	public List<Detalle> getDetalles() {
		return detalles;
	}
	public void setDetalles(List<Detalle> detalles) {
		this.detalles = detalles;
	}
	
}
