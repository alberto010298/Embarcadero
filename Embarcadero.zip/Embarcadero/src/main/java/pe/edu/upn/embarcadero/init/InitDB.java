package pe.edu.upn.embarcadero.init;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import pe.edu.upn.embarcadero.model.entity.Usuario;
import pe.edu.upn.embarcadero.model.repository.UsuarioRepository;

@Service
public class InitDB implements CommandLineRunner{

	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
    private PasswordEncoder passwordEncoder;

	@Override
	public void run(String... args) throws Exception {
		
		this.usuarioRepository.deleteAll();
		
		Usuario alberto = new Usuario();
		alberto.setUsername("admin");
		alberto.setPassword(passwordEncoder.encode("admin"));
		alberto.setApellidos("Castro");
		alberto.setNombre("Alberto");
		alberto.setRol("GERENTE");
		
        List<Usuario> usuarios = Arrays.asList(alberto);        
        this.usuarioRepository.saveAll(usuarios);
	}
}
