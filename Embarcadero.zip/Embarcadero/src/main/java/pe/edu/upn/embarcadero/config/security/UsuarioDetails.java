package pe.edu.upn.embarcadero.config.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import pe.edu.upn.embarcadero.model.entity.Usuario;


// Implementación de una clase detail que manipula al usuario
public class UsuarioDetails implements UserDetails{

	private static final long serialVersionUID = 1L;
	
	// @Autowired
	private pe.edu.upn.embarcadero.model.entity.Usuario usuario;	
	public UsuarioDetails(Usuario usuario) {
		super();
		this.usuario = usuario;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		
		// Extraer la lista de las Authorities
		// Solucion
		//https://ducmanhphan.github.io/2019-02-20-Problem-about-role-name-in-Spring-Security/
		GrantedAuthority grantedAuthority = new SimpleGrantedAuthority("ROLE_"+usuario.getRol());
		grantedAuthorities.add(grantedAuthority);
		return grantedAuthorities;
	}

	@Override
	public String getPassword() {
		return this.usuario.getPassword();
	}

	@Override
	public String getUsername() {
		return this.usuario.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	
	// Datos de la Clase Usuario
	public Integer getId() {
		return this.usuario.getId();
	}
	
	public String getNombres() {
		return this.usuario.getNombre();
	}
	public String getApellidos() {
		return this.usuario.getApellidos();
	}
	public String getCargo() {
		return this.usuario.getRol();
	}

}
