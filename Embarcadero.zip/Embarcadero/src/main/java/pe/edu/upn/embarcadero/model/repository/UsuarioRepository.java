package pe.edu.upn.embarcadero.model.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import pe.edu.upn.embarcadero.model.entity.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer>{
	Optional<Usuario> findByUsername(String username);
	
	@Query(value = "select u from Usuario u where u.rol = 'CAMARERO' ")
	List<Usuario> findbyRol();
}
