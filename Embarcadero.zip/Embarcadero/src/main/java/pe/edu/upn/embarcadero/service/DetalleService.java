package pe.edu.upn.embarcadero.service;

import pe.edu.upn.embarcadero.model.entity.Detalle;

public interface DetalleService extends CrudService<Detalle, Integer>{

}
