package pe.edu.upn.embarcadero.service;

import pe.edu.upn.embarcadero.model.entity.Plato;

public interface PlatoService extends CrudService<Plato, Integer>{

}
