package pe.edu.upn.embarcadero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmbarcaderoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmbarcaderoApplication.class, args);
	}

}
