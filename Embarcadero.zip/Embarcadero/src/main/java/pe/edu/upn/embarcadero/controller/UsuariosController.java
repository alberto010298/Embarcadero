package pe.edu.upn.embarcadero.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import pe.edu.upn.embarcadero.model.entity.Usuario;
import pe.edu.upn.embarcadero.service.UsuarioService;


@Controller
@RequestMapping("/usuario")
@SessionAttributes({"usuario"})
public class UsuariosController {

	@Autowired
	UsuarioService usuarioService;
	
	@Autowired
    private PasswordEncoder passwordEncoder;
	
	@GetMapping
	public String inicio(Model model){
		try {
			List<Usuario> usuarios=usuarioService.findbyRol();
			model.addAttribute("usuarios",usuarios);
		} catch (Exception e) {
		}
		return "usuario/inicio";
	}
	
	@GetMapping("/actualizar/{id}")
	public String editar(@PathVariable("id") Integer id,Model model) {
		try {
			Optional<Usuario>optional=usuarioService.findById(id);
			if(optional.isPresent()) {
				model.addAttribute("usuario",optional.get());
			}else {
				return "redirect:/usuario";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "usuario/edit.html";
	}
	
	@GetMapping("/register")
	public String nuevo(Model model) {
		try {
			Usuario usuario=new Usuario();
			model.addAttribute("usuario",usuario);
		} catch (Exception e) {
		}
		return "usuario/register.html";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute("usuario") Usuario usuario, Model model, SessionStatus status) {
		try {
			usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
			usuario.setRol("CAMARERO");
			usuarioService.save(usuario);
			status.setComplete();
			model.addAttribute("success", "Camarero guardado");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/usuario";
	}
	
	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable("id") Integer id, Model model) {
		try {
			Optional<Usuario> usuarioOptional=usuarioService.findById(id);
			if(usuarioOptional.isPresent()) {
				usuarioService.deleteById(id);
			}
		} catch (Exception e) {
			model.addAttribute("danger_del","Error - Violacion contra el principio de integridad referencial");
			try {
				List<Usuario> usuario=usuarioService.findAll();
				model.addAttribute("usuario",usuario);
			} catch (Exception e1) {
			}
			return "/usuario/inicio";
		}
		return "redirect:/usuario";
	}
	
	@GetMapping("/clienteregister")
	public String clienteRegister(Model model) {
		try {
			Usuario usuario=new Usuario();
			model.addAttribute("usuario",usuario);
		} catch (Exception e) {
		}
		return "usuario/clienteregister.html";
	}
	
	@PostMapping("/clienteguardar")
	public String clienteGuardar(@ModelAttribute("usuario") Usuario usuario, Model model, SessionStatus status) {
		try {
			usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
			usuario.setRol("CLIENTE");
			usuarioService.save(usuario);
			status.setComplete();
			model.addAttribute("success", "Cliente guardado");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/login";
	}
}
