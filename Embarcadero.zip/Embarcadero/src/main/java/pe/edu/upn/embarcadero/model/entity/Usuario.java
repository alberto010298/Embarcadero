package pe.edu.upn.embarcadero.model.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "usuarios")
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "nomb_usuario", length = 60)
	private String nombre;
	
	@Column(name = "ape_usuario", length = 60)
	private String apellidos;
	
	@Column(length = 30, nullable = false)
	private String username;

	@Column(length = 60, nullable = false)
	private String password;
	
	@Column(name = "rol_usuario", length = 60)
	private String rol;
	
	@OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
	public List<Detalle> detalles;
	
	public Usuario() {
		this.detalles = new ArrayList<>();
	}
	
	public void addDetalle(Detalle detalle) {
		detalle.setUsuario(this);
		this.detalles.add(detalle);
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public List<Detalle> getDetalles() {
		return detalles;
	}

	public void setDetalles(List<Detalle> detalles) {
		this.detalles = detalles;
	}

}
