package pe.edu.upn.embarcadero.config.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import pe.edu.upn.embarcadero.model.entity.Usuario;
import pe.edu.upn.embarcadero.model.repository.UsuarioRepository;


@Service
public class UsuarioDetailsService implements UserDetailsService{

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Retornando cualquiera de los usuarios buscados
		Optional<Usuario> usuarioBuscado = this.usuarioRepository.findByUsername(username);
		
		if(usuarioBuscado.isPresent()) {
			UsuarioDetails usuarioDetails = new UsuarioDetails(usuarioBuscado.get());
			return usuarioDetails;
		}
		throw new UsernameNotFoundException("Usuario invalido!");
	}
}
