package pe.edu.upn.embarcadero.config.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	@Autowired
	private UsuarioDetailsService usuarioDetailsService;
	
	@Autowired
    private LoggingAccessDeniedHandler accessDeniedHandler;
	
	/*@Autowired
    private PasswordEncoder passwordEncoder;*/
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/index").permitAll()
				.antMatchers("/reportes").hasRole("ADMINISTRADOR")//permitAll()
				.antMatchers("/direcciones").hasRole("ADMINISTRADOR")
				.antMatchers("/alumno/**").hasRole("ADMINISTRADOR")
				.antMatchers("/padre/**").hasRole("ADMINISTRADOR")
				.antMatchers("/colegio/**").hasRole("ADMINISTRADOR")
				.antMatchers("/distrito/**").hasRole("ADMINISTRADOR")
				.antMatchers("/universidad/**").hasRole("ADMINISTRADOR")
				.antMatchers("/profesor/**").hasRole("ADMINISTRADOR")
				.antMatchers("/curso/**").hasRole("ADMINISTRADOR")
				.antMatchers("/horarios/listarHorariosRegistrados").hasRole("ALUMNO")
				.antMatchers("/horarios").hasAnyRole("ALUMNO","ADMINISTRADOR")
				.antMatchers("/horarios/listarHorariosDisponibles").hasRole("PROFESOR")
				.antMatchers("/horarios/listarHorariosPorPagar/**").hasRole("PADRE")
				.antMatchers("/horarios/pago").hasRole("PADRE")
				//.antMatchers("/docentes/**").hasAuthority("ACCESS_REST1")
				//.antMatchers("/api/rest1").hasAuthority("ACCESS_REST1")
				//.antMatchers("/api/rest2").hasAuthority("ACCESS_REST2")
				//.antMatchers("/api/usuarios").hasRole("ADMIN")
			.and()
			.formLogin()
				.loginProcessingUrl("/ingresar")
				.loginPage("/").permitAll()
				.usernameParameter("inputUsername")
                .passwordParameter("inputPassword")
                .defaultSuccessUrl("/")
			.and()
	        .logout()
	        	.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
	        	.logoutSuccessUrl("/")
	        .and()
            .rememberMe()
            	.tokenValiditySeconds(2592000)
            	.key("Cl4v3.")
            	.rememberMeParameter("checkRememberMe")
            	.userDetailsService(usuarioDetailsService)
            .and()
                .exceptionHandling()
                    .accessDeniedHandler(accessDeniedHandler);
		
	}
	
	/*@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		/*auth.inMemoryAuthentication()
        .withUser("keycuevas").password(passwordEncoder.encode("1234567")).roles("ADMINISTRADOR")
        .and()
        .withUser("abigailcuevas").password(passwordEncoder.encode("1234567")).roles("ALUMNO")
        .and()
        .withUser("alumno").password("contrasena").roles("ALUMNO");
	}*/
	
	/*@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.httpBasic()
		.and()
		.authorizeRequests()
		.anyRequest().authenticated();
	}*/
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}
	
	@Bean
    DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
        daoAuthenticationProvider.setUserDetailsService(usuarioDetailsService);

        return daoAuthenticationProvider;
    }
	
	//Esto es para utilizar la encriptacion desde nuestro servicio
	@Bean
	PasswordEncoder passwordEncoder( ) {
		return new BCryptPasswordEncoder();
	}
	
}
