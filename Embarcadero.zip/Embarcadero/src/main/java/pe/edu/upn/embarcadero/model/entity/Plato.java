package pe.edu.upn.embarcadero.model.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "platos")
public class Plato {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "nom_plato", length = 60)
	private String nombre;
	
	@Column(name = "precio")
	private Float precio;
		
	@Column(name = "estado_plato", length = 60)
	private String estadoPlato;
	
	@OneToMany(mappedBy = "plato", fetch = FetchType.LAZY)
	public List<Detalle> detalles;
	
	public Plato() {
		this.detalles = new ArrayList<>();
	}
	
	public void addDetalle(Detalle detalle) {
		detalle.setPlato(this);
		this.detalles.add(detalle);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Float getPrecio() {
		return precio;
	}

	public void setPrecio(Float precio) {
		this.precio = precio;
	}

	public String getEstadoPlato() {
		return estadoPlato;
	}

	public void setEstadoPlato(String estadoPlato) {
		this.estadoPlato = estadoPlato;
	}

	public List<Detalle> getDetalles() {
		return detalles;
	}

	public void setDetalles(List<Detalle> detalles) {
		this.detalles = detalles;
	}
	
	
}
