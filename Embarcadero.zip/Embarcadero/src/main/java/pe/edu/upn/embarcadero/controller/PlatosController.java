package pe.edu.upn.embarcadero.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import pe.edu.upn.embarcadero.model.entity.Plato;
import pe.edu.upn.embarcadero.service.PlatoService;

@Controller
@RequestMapping("/plato")
@SessionAttributes({"plato"})
public class PlatosController {
	@Autowired
	PlatoService platoService;
	
	@GetMapping
	public String inicio(Model model){
		try {
			List<Plato> platos=platoService.findAll();
			model.addAttribute("platos",platos);
		} catch (Exception e) {
		}
		return "plato/inicio.html";
	}
	
	@GetMapping("/actualizar/{id}")
	public String editar(@PathVariable("id") Integer id,Model model) {
		try {
			Optional<Plato>optional=platoService.findById(id);
			if(optional.isPresent()) {
				model.addAttribute("plato",optional.get());
			}else {
				return "redirect:/plato";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "plato/edit.html";
	}
	
	@GetMapping("/register")
	public String nuevo(Model model) {
		try {
			Plato plato=new Plato();
			model.addAttribute("plato",plato);
		} catch (Exception e) {
		}
		return "plato/register.html";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute("plato") Plato plato, Model model, SessionStatus status) {
		try {
			platoService.save(plato);
			status.setComplete();
			model.addAttribute("success", "Plato guardado");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/plato";
	}
	
	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable("id") Integer id, Model model) {
		try {
			Optional<Plato> platoOptional=platoService.findById(id);
			if(platoOptional.isPresent()) {
				platoService.deleteById(id);
			}
		} catch (Exception e) {
			model.addAttribute("danger_del","Error - Violacion contra el principio de integridad referencial");
			try {
				List<Plato> plato=platoService.findAll();
				model.addAttribute("plato",plato);
			} catch (Exception e1) {
			}
			return "/plato/inicio";
		}
		return "redirect:/plato";
	}
}
