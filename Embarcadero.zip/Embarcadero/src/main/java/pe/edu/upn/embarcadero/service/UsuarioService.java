package pe.edu.upn.embarcadero.service;

import java.util.List;

import pe.edu.upn.embarcadero.model.entity.Usuario;

public interface UsuarioService extends CrudService<Usuario, Integer>{
	List<Usuario> findbyRol() throws Exception;
}
