package pe.edu.upn.embarcadero.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upn.embarcadero.model.entity.Detalle;
import pe.edu.upn.embarcadero.model.repository.DetalleRepository;
import pe.edu.upn.embarcadero.service.DetalleService;

@Service
public class DetalleServiceImpl implements DetalleService{

	@Autowired
	private DetalleRepository detalleRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<Detalle> findAll() throws Exception {
		return detalleRepository.findAll();
	}

	@Transactional(readOnly = true)
	@Override
	public Optional<Detalle> findById(Integer id) throws Exception {
		return detalleRepository.findById(id);
	}

	@Transactional
	@Override
	public Detalle save(Detalle entity) throws Exception {
		return detalleRepository.save(entity);
	}

	@Transactional
	@Override
	public Detalle update(Detalle entity) throws Exception {
		return detalleRepository.save(entity);
	}

	@Transactional
	@Override
	public void deleteById(Integer id) throws Exception {
		detalleRepository.deleteById(id);
	}

	@Transactional
	@Override
	public void deleteAll() throws Exception {
		detalleRepository.deleteAll();
	}

}
