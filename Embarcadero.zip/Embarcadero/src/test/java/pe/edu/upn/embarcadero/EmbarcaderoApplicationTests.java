package pe.edu.upn.embarcadero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmbarcaderoApplicationTests {

	@Test
	void contextLoads() {
	}

}
